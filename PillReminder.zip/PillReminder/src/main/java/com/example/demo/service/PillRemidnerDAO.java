package com.example.demo.service;

import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.demo.model.Register;
import com.example.demo.model.User;

public interface PillRemidnerDAO {
	public String renderLogin();
	public String doLogin(@ModelAttribute Register reg);
	public String doRegister(@ModelAttribute Register reg);
	public String renderRegister();
	int addUser(Register reg);
}
