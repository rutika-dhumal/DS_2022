package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.Register;
import com.example.demo.model.User;
import com.example.demo.service.PillRemidnerDAO;
@Controller
public class PillReminderDAOImpl implements PillRemidnerDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	@GetMapping("/index")
	public String renderLogin() {
		return "index";
	}
	
	
	
	@Override
	@RequestMapping(path = "/loginUser",method = RequestMethod.GET)
	public String doLogin(Register register) {
		String sql = "SELECT * FROM REGISTRATION1 WHERE EMAIL = ?";
		System.out.println(register);
		Register newUser= (Register) jdbcTemplate.queryForObject(
				sql, 
				new Object[]{register.getEmail()}, 
				new BeanPropertyRowMapper(Register.class));
		if((newUser.getEmail().equals(register.getEmail()))&&(newUser.getPasswd().equals(register.getPasswd()))) {
			System.out.println("Valid Credentials");
			return "dashboard";
		}
		else {
			System.out.println(newUser.getEmail()+" "+newUser.getPasswd());
			System.out.println("Invalid");
			return "index";
		}
		
	}

	@Override
	@RequestMapping(path = "/registerUser",method = RequestMethod.GET)
	public String doRegister(Register reg) {
		System.out.println(reg);
		
		 jdbcTemplate.update("insert into registration1 values (?,?,?,?,?,?,?)",
				 new Object[] {reg.getName() , reg.getEmail() , reg.getContact_no(),reg.getCountry() ,reg.getBirthdate(),reg.getPasswd(),reg.getCpasswd()});
		 
		return "index";
	}



	@Override
	@GetMapping("/register")
	public String renderRegister() {
		return "register";
	}



	@Override
	public int addUser(Register reg) {
		
		return 0;
	}
	

}
