package com.example.demo.model;

import java.sql.Date;


public class Register
{
	private String name;
	private String email;
	private String contact_no;
	private String country;
	private Date birthdate;
	private String passwd;
	private String cpasswd;
	
	
	
	
	
	public Register() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getCpasswd() {
		return cpasswd;
	}
	public void setCpasswd(String cpasswd) {
		this.cpasswd = cpasswd;
	}
	@Override
	public String toString() {
		return "Register [name=" + name + ", email=" + email + ", contact_no=" + contact_no + ", country=" + country
				+ ", birthdate=" + birthdate + ", passwd=" + passwd + ", cpasswd=" + cpasswd + "]";
	}
	
	
}

	

